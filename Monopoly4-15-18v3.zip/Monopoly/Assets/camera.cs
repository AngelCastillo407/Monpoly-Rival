﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour {

    Vector3 myPosition = new Vector3(0,0,-100); // this is how far away i want the camera
    public Player currentPlayer;// the current player
    public GameBoard gameInfo; //game board ref


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = gameInfo.GetActivePlayer().transform.position + myPosition; // update camera position
	}
}
