﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dice_Roller : MonoBehaviour {

    public int[] Values;
    public int totalDiceValue;
    public GameBoard gameBoard;
    // Use this for initialization
    void Start() {
        Values = new int[2]; // holds two values one for each die
        //gameBoard = GameObject.FindObjectOfType<GameBoard>(); // get a reference to gameboard to be able to send info

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    private void Roll() {
        totalDiceValue = 0;
        for (int i = 0; i < Values.Length; i++) { //find two random values and add them to the array
            Values[i] = Random.Range(1,7);
            totalDiceValue += Values[i]; // incrament the total value of the dice
        }

        // since we rolled we need to move
        Debug.Log("Rolled " + totalDiceValue + "\n");
        gameBoard.GetActivePlayer().Move(totalDiceValue); // get the active player from the gameboard, and tell that player to move
        gameBoard.IncActivePlayer();

        
    }
}
