﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


// this will handle the turn indicator


public class TurnIndicator : MonoBehaviour {

    public Text curPlayerName; // refs to text objects and gameboard
    public Text playerStatus;
    public Text creditHours;
    public GameBoard gameInfo;

    

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        curPlayerName.text = "The current player is " + gameInfo.GetActivePlayer().playerName;

        creditHours.text = "Credits = " + gameInfo.GetActivePlayer().hours;

        if (gameInfo.GetActivePlayer().probation == true)
        {
            playerStatus.text = "Player Status is \nProbation";
        }
        else {
            playerStatus.text = "Player Status is \nGood Standing";
        }
    
	}
}
