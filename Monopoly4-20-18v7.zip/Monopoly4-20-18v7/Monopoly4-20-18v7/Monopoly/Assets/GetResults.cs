﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GetResults : MonoBehaviour {

    public Text name1, name2, name3, name4; 
    public Text score1, score2, score3, score4; 
    public Text winner; 
    public Button quit;
    public string winnerName;
    public int winnerScore = 0;
    public GameBoard tempBoard = null;
    public int[] newScores;

    public void showResults()
    {
        
        tempBoard = GameObject.FindObjectOfType<GameBoard>();
        //players = tempBoard.players;


        /*
        Player temp = new Player();

        for (int i = 0; i < 4; i++)
        {
            players[i] = temp;
        }
        */

        /*
        foreach(Player p in tempBoard.players)
        {
            players[count] = p;    
            count++;
        }
        /*
        players[0].SetName("Alice");
        players[0].SetScore(100);
        players[1].SetName("Bob");
        players[1].SetScore(200);
        players[2].SetName("Carl");
        players[2].SetScore(300);
        players[3].SetName("Doug");
        players[3].SetScore(400);
        */


        name1.text = tempBoard.names[0];
        name2.text = tempBoard.names[1];
        name3.text = tempBoard.names[2];
        name4.text = tempBoard.names[3];
        score1.text = tempBoard.score1.ToString();
        score2.text = tempBoard.score2.ToString();
        score3.text = tempBoard.score3.ToString();
        score4.text = tempBoard.score4.ToString();





        winnerScore = tempBoard.score1;
        winnerName = tempBoard.names[0];

        if (tempBoard.score2 > winnerScore)
        {
            winnerScore = tempBoard.score2;
            winnerName = tempBoard.names[1];
        }
        if (tempBoard.score3 > winnerScore)
        {
            winnerScore = tempBoard.score3;
            winnerName = tempBoard.names[2];
        }
        if (tempBoard.score4 > winnerScore)
        {
            winnerScore = tempBoard.score4;
            winnerName = tempBoard.names[3];
        }        

        winner.text = String.Format("{0}\n{1}", winnerName, winnerScore.ToString());

    }

    public void quit_Game()
    {
        Application.Quit();
    }

    // Use this for initialization
    void Start () {
        showResults();
    }
	
	// Update is called once per frame
	void Update () {
        //showResults();
	}



}
