﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup : MonoBehaviour {

    public GameObject panel; // ref to the panel so we can activate and deactivate it
    public GameBoard gameInfo; // ref to Gameboard

    public Text buttonAText; // references for the text of the buttons
    public Text buttonBText;
    public Text buttonCText;
    public Text buttonDText;

    public GameObject buttonA; // refs for the buttons themselves as gameobjects so we can activate and deactivate them
    public GameObject buttonB;
    public GameObject buttonC;
    public GameObject buttonD;
    public GameObject acknowledgeButton;


    public Text popUpText; // refs for the popuptext

    public Tile tileWeAreServicing; // the tile that is asking for popup services

    public bool isPopping; // are we throwing a popup
    public bool isClass; // is the pop up a class one
    public bool isDirection;// is the popup a directional one

    public string answer; // the answer


    // Use this for initialization
    void Start () {
		
	}


    public void ButtonA() { // the user answered A give the current tile the info

        tileWeAreServicing.givenAnswer = buttonAText.text; // what was the answer

        tileWeAreServicing.gotAnswer = true; // tell them they got it

        //deactivate the panel
        panel.SetActive(false);

    }

    public void ButtonB() { // the user answered B give the current tile the info

        if (tileWeAreServicing.isDirectional == true) { // give the player the directional info if we are on a directional space
            //set the current player's direction to what it needs to be
            gameInfo.GetActivePlayer().direction = "left";

        } else if (tileWeAreServicing.isClass == true) {//if we are a class space
           tileWeAreServicing.givenAnswer = buttonBText.text; // what was the answer

            tileWeAreServicing.gotAnswer = true; // tell them they got it
        }

        //deactivate the panel
        panel.SetActive(false);

    }

    public void ButtonC() { // the user answered C give the current tile the info

        if (tileWeAreServicing.isDirectional == true) // give the player the directional info
        { // if we are on a directional space
            //set the current player's direction to what it needs to be
            gameInfo.GetActivePlayer().direction = "right";

        }
        else if (tileWeAreServicing.isClass == true)
        {//if we are a class space
            tileWeAreServicing.givenAnswer = buttonCText.text; // what was the answer

            tileWeAreServicing.gotAnswer = true; // tell them they got it
        }

        //deactivate the panel
        panel.SetActive(false);

    }

    public void ButtonD() { // the user answered D give the current tile the info

        tileWeAreServicing.givenAnswer = buttonDText.text; // what was the answer

        tileWeAreServicing.gotAnswer = true; // tell them they got it

        //deactivate the panel
        panel.SetActive(false);

    }

    public void Acknowledged() {


        acknowledgeButton.SetActive(false); // deactivate button
        panel.SetActive(false); // deactivate panel
    }


    public void MakeDirectionalPopUp() {



        // turn off the A and D buttons
        buttonA.SetActive(false);
        buttonD.SetActive(false);

        //activate B and C
        buttonB.SetActive(true);
        buttonC.SetActive(true);

        //turn on the popup panel
        panel.SetActive(true);

        popUpText.text = "This is a Directional Tile!/nWhich way would you like to go?";
        buttonBText.text = "Left";
        buttonCText.text = "Right";


    }


    public void EventPopUp(string text)
    {
        // deactivate all the buttons
        buttonA.SetActive(false);
        buttonB.SetActive(false);
        buttonC.SetActive(false);
        buttonD.SetActive(false);

        //activate the acknowledgeButton
        acknowledgeButton.SetActive(true);

        popUpText.text = text;
        panel.SetActive(true); // activate panel



    }


    public void MakeClassPopUp(string text, string choiceA, string choiceB, string choiceC, string choiceD) {

        // activate all the buttons
        buttonA.SetActive(true);
        buttonB.SetActive(true);
        buttonC.SetActive(true);
        buttonD.SetActive(true);

        //activate the panel
        panel.SetActive(true);

        //set the text
        buttonAText.text = choiceA;
        buttonBText.text = choiceB;
        buttonCText.text = choiceC;
        buttonDText.text = choiceD;

        //set the popup text
        popUpText.text = text;


    }

    public void MakeAnswerPopUp(bool a)
    {
        if (a == true) // we got it right
        {
            // deactivate all the buttons
            buttonA.SetActive(false);
            buttonB.SetActive(false);
            buttonC.SetActive(false);
            buttonD.SetActive(false);

            //activate the acknowledgeButton
            acknowledgeButton.SetActive(true);

            //turn on the popup panel
            panel.SetActive(true);

            popUpText.text = "You got the question Right!!!";

        }
        else { // we got it wrong
            // deactivate all the buttons
            buttonA.SetActive(false);
            buttonB.SetActive(false);
            buttonC.SetActive(false);
            buttonD.SetActive(false);


            //activate the acknowledgeButton
            acknowledgeButton.SetActive(true);


            //turn on the popup panel
            panel.SetActive(true);

            popUpText.text = "You got the question Wrong.";

        }
    }

    // Update is called once per frame
    void Update () {
		
	}
}
