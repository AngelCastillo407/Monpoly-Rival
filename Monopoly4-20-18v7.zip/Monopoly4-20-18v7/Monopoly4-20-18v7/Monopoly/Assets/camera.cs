﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour {

    Vector3 myPosition = new Vector3(0,0,-500); // this is how far away i want the camera
    public Player currentPlayer;// the current player
    public GameBoard gameInfo; //game board ref
    Vector3 targetPosition;


    Vector3 velocity = Vector3.zero;

    float smoothTime = 0.25f;

    float smoothDistance = 0.01f;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        //animate a smoother transition
        targetPosition = gameInfo.GetActivePlayer().transform.position + myPosition; // update camera position


        if (Vector3.Distance(new Vector3(transform.position.x, transform.position.y, transform.position.z), targetPosition) > smoothDistance) // if we are not at our position
        {
            this.transform.position = Vector3.SmoothDamp(
                    this.transform.position,

                    new Vector3(targetPosition.x, targetPosition.y, targetPosition.z),

                    ref velocity,

                    smoothTime);



        }



        //transform.position = gameInfo.GetActivePlayer().transform.position + myPosition; // update camera position




	}
}
