﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;



// this will be the main game program area
public class GameBoard : MonoBehaviour {
    static int PLAYERNUM = 4;
    public int activePlayer = 0;// the current active player
    public Player[] players;  //make an array of player objects of size player
    public string[] names; // array of player names
    public int[] scores;
    public Canvas popUpCanvas; // not used
    public Text popUpText; //not used
    public Text inputText; // not used
    int popUpNumber; // not used
    public int numberOfPlayers;
    public int numberOfTurns;
    public GetText gt; // this is the a start object that has info from the user like number of players, player names, and number of turns
    int turnCounter = 0; // this int keeps track of when we incrament the numberOfTurn int i.e. only after all four players have gone

    public Popup pop;

    public Tile[] tiles;

    public int score1;
    public int score2;
    public int score3;
    public int score4;

    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }


    // return the active player; a player object
    public Player GetActivePlayer()
    {
        Player active = players[activePlayer];
        return active;
    }
    // return the int index of the active player
    public int GetActive() {
        return activePlayer;
    }

    // starts the next Move for the next player
    public void StartMove() {
        IncActivePlayer();
        GetActivePlayer().SetHasMoved(false);
    }

    public void IncActivePlayer() { // incrament the active player, if the last player has gone, then inc turn 

        activePlayer += 1; // inc

        if (activePlayer == 4) { // we have gone through all players at least once
            numberOfTurns--; //dec turn count
            if (numberOfTurns <= 0) { // are we done with turns?
                End();
                return; // if you try to play past zero right now it will index array out of bounds you since we never mod activePlayer and instead return
            }

        }



        activePlayer = ((activePlayer) % 4); // mod the number of turns 

        if (players[activePlayer].isAI == true) { // are we an AI player
            // do AI stuff
        }



        Debug.Log("active player is  " + (activePlayer + 1) + "\n");
    }

    /*
Chance Events:
-------------
*/

    //Allows specific chance choices through debug. If you want to randomize/use normally pass in 0
    public void getEvent(int debug)
    {

        //Random number generator 1 through 20

        int randomNum = Random.Range(1, 20);

        //For debugging and allowing explicit choices
        if (debug != 0)
            randomNum = debug;

        //Get active player to be used as an index
        //int active = scoreboard.getActive(); // dont need since we are the active player

        //1. Be taken off academic probation! (if already off probation move 6 spaces ahead)
        if (randomNum == 1)
        {
            //If on probation, remove probation
            if (players[activePlayer].IsProbation() == true)
            {
                players[activePlayer].SetProbation(false);
                //Make pop-up with dialogue
                pop.EventPopUp("You kept good grades!\n" +
                           "(You are removed from Academic Probation)");
            }
            //Otherwise move 6
            else
            {
                //Make pop-up with dialogue
                pop.EventPopUp("You kept good grades!\n" +
                           "(Move ahead 6 spaces)");
                players[activePlayer].Move(6);
            }

        }

        //2. Caught Cheating! (Take away 4 from score and be put on Academic Probation)
        else if (randomNum == 2)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You were caught cheating!\n" +
                       "(Move back 4 spaces. You are put on Academic Probation)");
            players[activePlayer].SetScore(-4);
            players[activePlayer].SetProbation(true);
        }

        //3. You were able intern with Google for the summer! (Add 8 to your score)
        else if (randomNum == 3)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You interned with Google over the summer!\n" +
                       "(Your score is increased by 8)");
            players[activePlayer].SetScore(8);
        }

        //4. You partied too hard and overslept this and missed your final! (Take away 4 from score)
        else if (randomNum == 4)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You partied too hard and slept passed your final!\n" +
                       "(Your score is decreased by 4)");
            players[activePlayer].SetScore(-4);
        }

        //5. You went to Prof's Office Hours and suddenly everything makes sense! (Add 4 to score)
        else if (randomNum == 5)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You went to the Professor's office hours. Suddenly everything makes sense!\n" +
                       "(Your score is increased by 4)");
            players[activePlayer].SetScore(4);
        }

        //6. Caught trying to change your grades online! (Go back to 1 space after start)
        else if (randomNum == 6)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You were caught trying to change your grades online!\n" +
                       "(Move to 1 space after the start)");
            players[activePlayer].SetPosition(); // TODO
        }

        //7. Professor starts dating your mom! (Add 4 to your score)
        else if (randomNum == 7)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("A professor starts dating your mom!\n" +
                       "(Your score is increased by 4)");
            players[activePlayer].SetScore(4);
        }

        //8. Mom breaks up with Professor! (Subtract 4 from score)
        else if (randomNum == 7)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Your mom breaks up with your professor whom she was dating!\n" +
                       "(Your score is decreased by 4)");
            players[activePlayer].SetScore(-4);
        }

        //9. Professor got sick and cancelled class! (Add 4 to credit hours)
        else if (randomNum == 9)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Your professor got sick and cancelled class!\n" +
                       "(Your credit hours have increased by 4)");
            players[activePlayer].SetHours(4);
        }

        //10. You got into a car accident with a Freshman (Subtract 4 credit hours)
        else if (randomNum == 10)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You got into a car accident with a freshman!\n" +
                       "(Your credit hours have decreased by 4)");
            players[activePlayer].SetHours(-4);
        }

        //11. The professor curved the exam and you now have an A! (Add 4 to score)
        else if (randomNum == 11)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Your exam was curved and you now have an A!" +
                       "(Your score is increased by 4)");
            players[activePlayer].SetScore(4);
        }

        //12. Hurricane Knightro makes school take heavy damage! (Decrement final turn by 1)
        else if (randomNum == 12)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Hurricane Knightro causes heavy damage to the school!\n" +
                       "(Turn count is decreased by 1)");
            numberOfTurns--;
        }

        //13. Final Exams are pushed back an entire week! (Increment final turn by 1)
        else if (randomNum == 13)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Finals are pushed back a week!\n" +
                       "(Turn count is increased by 1)");
            numberOfTurns++;
        }

        //14. School database was corrupted! (Your name in the system is now your name backwards)
        else if (randomNum == 14)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("The school database was corrupted!\n" +
                       "(Your name is now backwards)");
            char[] temp = players[activePlayer].GetName().ToCharArray(); /// holds a char array of the current player name
            string newName = string.Empty; // empty string

            for (int i = (temp.Length - 1); i > -1; i--) // start at the end of the char array
            {
                newName += temp[i]; // add each char back to the empty string to build the new name
            }
            players[activePlayer].SetName(newName); // set name
        }

        //15. You reported your classmate for cheating and were rewarded! (Add 4 to your score and subtract 4 from next players turn) 
        else if (randomNum == 15)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You reported a classmate for cheating and were rewarded!\n" +
                       "(Your score is increased by 4 and the next player's score is decreased by 4)");
            players[activePlayer].SetScore(4);
            players[(GetActive() + 1) % 4].SetScore(-4);

        }

        //16. You found a parking space on the first floor! (Collect all of the credit hours from chance counter, set to 0)
        else if (randomNum == 16)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You found a parking space on the first floor!\n" +
                       "(Collect credit hours from the accumulated chance pot [Which is currently a static 4])");
            players[activePlayer].SetHours(4);
            //chanceCounter = 0;
        }

        //17. Your football team won the Citrus Bowl! (Your Team Spirit is at an all-time high!)
        else if (randomNum == 17)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Your football team won the Citrus Bowl!\n" +
                       "(Your team spirit is at an all-time high. Go Knights!)");
        }

        //18. Your Social Security was stolen by a failing student! (Swap score with lowest scoring player)
        else if (randomNum == 18)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Your social security number was stolen by a failing student!\n" +
                       "(You and the lowest scoring player swap scores)");
            int tempi = GetActive(); // temp values for active player index and score
            int tempScore = players[activePlayer].GetScore();
            for (int i = 0; i < 3; i++) //search through all players
            {
                if (tempScore > players[i].GetScore()) // if we find a smaller score
                {
                    tempi = i; // get index
                    tempScore = players[i].GetScore(); // get the score
                }
            }

            players[tempi].SetScore(players[activePlayer].GetScore()); // make the smaller scoring player's score the current player's score
            players[activePlayer].SetScore(tempScore); // set the current player the temp score, ehich should be the lowest player's score
        }

        //19. You completed an extra credit assignment! (Add 4 to score)
        else if (randomNum == 19)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("You completed an extra credit assignment!\n" +
                       "(Your score is increased by 4)");
            players[activePlayer].SetScore(4);
        }

        //20. Your credits from previous schools didn't transfer correctly! (Set credit hour to 0)
        else if (randomNum == 20)
        {
            //Make pop-up with dialogue
            pop.EventPopUp("Your credits from previous schools didn't transfer correctly!\n" +
                       "(Your credit hours have been set to 0)");
            players[activePlayer].SetHours(-players[activePlayer].GetHours());
        }

    }







    // this will handle ending the game
    void End() {
        score1 = players[0].GetScore();
        score2 = players[1].GetScore();
        score3 = players[2].GetScore();
        score4 = players[3].GetScore();
        Awake();
        SceneManager.LoadScene("End_Game");


    }

    



    // Use this for initialization
    void Start () {
        // this will have the initial popups asking how many players and names
        /*
        
        //names = new string[] {"com1","com2","com3","com4" }; // everyone is a computer untill further notice
        //set up the popup
        //popUpNumber = 0;
        //TODO popup asking number of players
        popUpText.text = "How Many Players?";
        popUpCanvas.enabled = true; //enable popup canvas
        




        //TODO popup  asking names
        for (int i = 0; i < numberOfPlayers;) {
            popUpText.text = "What is Player " + (i+1) + "'s name?";
            popUpNumber++;

        }

        //TODO popup asking how many turns
        popUpNumber = 10;
        popUpText.text = "How many turns?";



        popUpCanvas.enabled = false; // close popup canvas

        */
        gt = GameObject.FindObjectOfType<GetText>();

        //get stuff from previous scene
        numberOfPlayers = gt.numPlayers;
        numberOfTurns = gt.numTurns;
        names = gt.playerNames;
        // if we have less than four players make the rest computer players (AI)
        if (numberOfPlayers < 4) {
            for (int i = numberOfPlayers; i < 4 ; i++) {
                names[i] = ("com" + (i + 1));
                players[i].isAI = true; // set them as AIs
            }

        }

        for (int i = 0; i < 4;i++) { // set all player names
            players[i].playerName = names[i];
        }


        //set The board


        foreach (Tile t in tiles) { // for all the tiles
            if(t.isClass == true) // if it is a question space
            {
                t.GetNewQuestion(); // get a new question
            }

        }



    }

    public void ButtonPress()
    {
        
    }

    // not used
    public void TextChanged() { // on text change
        string newText = inputText.text;
        if (popUpNumber == 0) {
            numberOfPlayers = int.Parse(newText);
        }
        else if (popUpNumber == 10) {
            numberOfTurns = int.Parse(newText);

        }
        else
        {
            names[popUpNumber] = newText; // set name of player
        }
        

    }




	// Update is called once per frame
	void Update () {
		
	}
}
