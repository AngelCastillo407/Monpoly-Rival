﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// this will handle the turn indicator
public class TurnIndicator : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
