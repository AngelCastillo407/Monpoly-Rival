﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// this will deal with the scoreboard and handle updating 
public class ScoreBoard : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
