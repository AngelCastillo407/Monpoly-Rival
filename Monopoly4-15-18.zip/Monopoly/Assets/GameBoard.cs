﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



// this will be the main game program area
public class GameBoard : MonoBehaviour {
    static int PLAYERNUM = 4;
    public int activePlayer = 0;// the current active player
    public Player[] players;  //make an array of player objects of size player
    public string[] names;
    public Canvas popUpCanvas;
    public Text popUpText;
    public Text inputText;
    int popUpNumber;
    public int numberOfPlayers;
    public int numberOfTurns;
    public GetText gt;

    // return the active player
    public Player GetActivePlayer()
    {
        Player active = players[activePlayer];
        return active;
    }
    public void IncActivePlayer() {
        activePlayer = ((activePlayer+1) % 4);
        //activePlayer = activePlayer + 1;
        Debug.Log("active player is  " + activePlayer + "\n");
    }
    void End() { // end stuff?

    }



    // Use this for initialization
    void Start () {
        // this will have the initial popups asking how many players and names
        /*
        
        //names = new string[] {"com1","com2","com3","com4" }; // everyone is a computer untill further notice
        //set up the popup
        //popUpNumber = 0;
        //TODO popup asking number of players
        popUpText.text = "How Many Players?";
        popUpCanvas.enabled = true; //enable popup canvas
        




        //TODO popup  asking names
        for (int i = 0; i < numberOfPlayers;) {
            popUpText.text = "What is Player " + (i+1) + "'s name?";
            popUpNumber++;

        }

        //TODO popup asking how many turns
        popUpNumber = 10;
        popUpText.text = "How many turns?";



        popUpCanvas.enabled = false; // close popup canvas

        */
        gt = GameObject.FindObjectOfType<GetText>();

        //get stuff from previous scene
        numberOfPlayers = gt.numPlayers;
        numberOfTurns = gt.numTurns;
        names = gt.playerNames;

    }

    public void ButtonPress()
    {
        
    }

    public void TextChanged() { // on text change
        string newText = inputText.text;
        if (popUpNumber == 0) {
            numberOfPlayers = int.Parse(newText);
        }
        else if (popUpNumber == 10) {
            numberOfTurns = int.Parse(newText);

        }
        else
        {
            names[popUpNumber] = newText; // set name of player
        }
        

    }




	// Update is called once per frame
	void Update () {
		
	}
}
