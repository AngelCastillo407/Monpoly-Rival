﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public Tile CurrentTile;
    //Dice_Roller Roller;
    public int score;
    public int hours;
    public string playerName;
    public bool probation;
    public bool isAnimating; // are we animating yet
    public Sprite piece;

	// Use this for initialization
	void Start ()
    {
        //Roller = GameObject.FindObjectOfType<Dice_Roller>();
        //score = 0;
        //hours = 120;
        //probation = false;

	}
    //needs an int to know how many spaces to move
    public void Move(int spaceToMove) {// if we are just moving
        int spacesLeft = spaceToMove;
        Debug.Log("Player " + playerName + " Moving  " + spacesLeft + "\n");
        
        while (spacesLeft != 0)
        {
            if (CurrentTile.isDirectional == true) {// if we are on a directional tile

                // do directional stuff ie choose direction
                CurrentTile = CurrentTile.nextTile; // make the current tile the next tile
                //animate move
                transform.position = CurrentTile.transform.position; // make the sprite have the same postion as the current tile
            } else if (CurrentTile.isStart == true) { // if we are the start tile then we get stuff
                // get stuff
                //move on
                CurrentTile = CurrentTile.nextTile; // make the current tile the next tile
                //animate move
                transform.position = CurrentTile.transform.position; // make the sprite have the same postion as the current tile
            }
            else {
                CurrentTile = CurrentTile.nextTile; // make the current tile the next tile
                //animate move
                transform.position = CurrentTile.transform.position; // make the sprite have the same postion as the current tile

            }

            spacesLeft--; // decrament the number of spaces left, IMPORTANT
        }
        
        // after we are done moving, we land on a tile
        Land();
    }

    public void Land() {// we are landing on the current space
        if (CurrentTile.isClass)
        {//if this is a class space then do class stuff
            Debug.Log("Landed on  " + CurrentTile.name + "\n");
        }
        else { // this should be a chance space
            //chance stuff
            Debug.Log("Landed on  " + CurrentTile.name + "\n");
        }
    }

    // Update is called once per frame
    void Update () {
		
	}
}
