﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GetText : MonoBehaviour {

    public Text info;
    public Text inputText;
    public Button apply;
    public Text buttonText;
    public int numPlayers;
    public int numTurns;
    public string[] playerNames;
    bool gotNumPlayers;
    bool gotNames;
    bool gotTurns;
    int tempNum = 0;


    public void GetInputText() {
        if (gotNumPlayers == false) { // do we have number of players
            if (inputText.text != null) { // make sure it is not empty
                numPlayers = int.Parse(inputText.text); //parse it
                
                gotNumPlayers = true; //we got the players
                if (numPlayers > 0) // more than one player
                {
                    info.text = "Enter Player " + (tempNum + 1) + "'s name."; // set up for next question
                }
                inputText.text = ""; // clear old stuff
            }

            

        }
        else if (gotNames == false) { // do we have Names
            
            

                if (inputText.text != null) { // make sure it is not empty
                    playerNames[tempNum] = inputText.text;
                }
                tempNum++; // incrament the number of players
                if (tempNum != numPlayers) // ready the text for next name unless we are at the end
                {
                    info.text = "Enter Player " + (tempNum + 1) + "'s name.";
                }
                else {
                    gotNames = true; // we got all players
                    info.text = "Enter number of turns";
                    inputText.text = ""; // clear old stuff
                } 
                inputText.text = ""; // clear old stuff
                
            
        }
        else if (gotTurns == false) { // do we have turns

            if (inputText.text != null)
            { // make sure it is not empty
                numTurns = int.Parse(inputText.text); //parse it
                gotTurns = true; //we got the players

                info.text = "Press start game to start";
                buttonText.text = "start Game";

            }
        }
        else { // we are done go to game

            //pass info



            SceneManager.LoadScene("Monopoly_scene"); //load game
             

        }
        Debug.Log("pressed button \n");
    }



    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
