﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// this willl govern behavior for the tiles
// they need to know which tile is next to move to
// they need to know what type of tile they are 
// they need to know their name
// their image
// their  
public class Tile : MonoBehaviour {
    public Tile nextTile; // point to next tile
    public Tile otherNextTile; // is this a branching path
    public Player[] PlayersOnTile; // players on the tile
    public bool isDirectional; // is this a directional space
    public bool isClass; // is this a class space
    public bool isChance; // is this a chance space
    public bool isStart; // is this the start space
    public string classType; // type of class tile
    public int difficulty; // difficulty of tile
    public Sprite tileFace; // what does the tile look like 



    public void Land() { // this space is being landed on 


    }

    public void GetNewQuestion() { // we had a player land on and answer our question, we need a new one


    }

    // Use this for initialization
    void Start () {
		// ask for question and get info from DB at start
        // get tile face based on the tile type





	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
