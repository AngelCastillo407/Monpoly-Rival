﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// this is just a script for managing the start scene, it grabs some info from the user, loads the game and then passes the info to the game
public class GetText : MonoBehaviour {

    public Text info; // this is the text above the input field
    public Text inputText; // text that is input to the input field
    public InputField textEntry; // the input field itself
    public Button apply; // the button, not used yet
    public Text buttonText; // the text on the button
    public int numPlayers; // number of players
    public int numTurns; // number of turns
    public string[] playerNames; // all the names of the player
    bool gotNumPlayers; // booleans for what info we have
    bool gotNames;
    bool gotTurns;
    int tempNum = 0; // temp value for number of players


    public void GetInputText() {
        if (gotNumPlayers == false) { // do we have number of players
            if (inputText.text != null) { // make sure it is not empty
                numPlayers = int.Parse(inputText.text); //parse it

                if (numPlayers > 4 || numPlayers < 0) { // too many players or too few
                    info.text = "Please enter the number of players from either one to four."; // don't be dumb
                    textEntry.text = ""; // trying this
                    return; // get out
                }


                gotNumPlayers = true; //we got the players
                if (numPlayers > 0) // more than one player
                {
                    info.text = "Enter Player " + (tempNum + 1) + "'s name."; // set up for next question
                }
                //inputText.text = ""; // clear old stuff in the text box, this didn't work
                textEntry.text = ""; // trying this
            }

            

        }
        else if (gotNames == false) { // do we have Names
            
            

                if (inputText.text != null) { // make sure it is not empty
                    playerNames[tempNum] = inputText.text;
                }
                tempNum++; // incrament the number of players
                if (tempNum != numPlayers) // ready the text for next name unless we are at the end
                {
                    info.text = "Enter Player " + (tempNum + 1) + "'s name.";
                }
                else {
                    gotNames = true; // we got all players
                    info.text = "Enter number of turns";
                    //inputText.text = ""; // clear old stuff
                    textEntry.text = ""; // trying this
                } 
                //inputText.text = ""; // clear old stuff
                textEntry.text = ""; // trying this


        }
        else if (gotTurns == false) { // do we have turns

            if (inputText.text != null)
            { // make sure it is not empty
                numTurns = int.Parse(inputText.text); //parse it
                gotTurns = true; //we got the players

                info.text = "Press start game to start";
                buttonText.text = "start Game";
               textEntry.text = ""; // trying this

            }
        }
        else { // we are done go to game

            //pass info



            SceneManager.LoadScene("Monopoly_scene"); //load game
             

        }
        Debug.Log("pressed button \n");
    }


    // this tells unity to not destroy this game object when loading another scene, the next scene can now use the info in this object 
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
