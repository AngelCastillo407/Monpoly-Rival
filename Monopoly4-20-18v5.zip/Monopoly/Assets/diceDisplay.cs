﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class diceDisplay : MonoBehaviour {
    Dice_Roller Dice_Roll;
	// Use this for initialization
	void Start () {
        Dice_Roll = GameObject.FindObjectOfType<Dice_Roller>(); // find the dice roller object to read the value of the dice
	}
	
	// Update is called once per frame
	void Update () {
        GetComponent<Text>().text = " " + Dice_Roll.totalDiceValue; //update the dice value constantly
	}
}
