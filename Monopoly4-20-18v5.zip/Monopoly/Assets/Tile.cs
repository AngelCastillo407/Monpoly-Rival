﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// this willl govern behavior for the tiles
// they need to know which tile is next to move to
// they need to know what type of tile they are 
// they need to know their name
// their image
// their question ? 
public class Tile : MonoBehaviour {
    public Tile nextTile; // point to next tile
    public Tile otherNextTile; // is this a branching path
    public Player[] PlayersOnTile; // players on the tile
    public bool isDirectional; // is this a directional space
    public bool isClass; // is this a class space
    public bool isChance; // is this a chance space
    public bool isStart; // is this the start space
    public string classType; // type of class tile
    public int difficulty; // difficulty of tile
    public Sprite tileFace; // what does the tile look like 

    public Question questionHandler; // this will handle the questions

    public bool isWaiting;
    public bool gotAnswer;
    public string givenAnswer;

    

    public Popup pop;

    public GameBoard gameInfo; // ref for Gameboard, AHHHHHHHHHHHHHHHHHHHHHHHHH

    string text = "this is a test question";

    public string[] answers;

    string answerA = "this is test answer 1";
    string answerB = "this is test answer 2";
    string answerC = "this is test answer 3";
    string answerD = "this is test answer 4";

    string correctAnswer = "B"; // the correct answer, currently test

    public void Land() { // this space is being landed on 

        //is waiting  = true 
        isWaiting = true;
        // findpopup
        //pop = GameObject.FindObjectOfType<Popup>(); // find the popup handler
        //hand popup this tile



        pop.tileWeAreServicing = this; // pop up is servicing this tile


        // makepopup

        if (isClass == true)
        {

            
            pop.MakeClassPopUp( text, answers[0], answers[1], answers[2], answers[3]); // make the popup with the info we have


        }
        else if (isChance == true) {
            //make a chance popup?

            gameInfo.getEvent(0);
        }
        // we are now waiting on update to tell us we have an answer


    }


    public void GetDirection() {
        //isWaiting = true; // the tile doesn't wait for this the player does
        // findpopup
        pop = GameObject.FindObjectOfType<Popup>(); // find the popup handler
        //hand popup this tile
        pop.tileWeAreServicing = this; // pop up is servicing this tile


        // makepopup
        pop.MakeDirectionalPopUp();
        
    }



    public void GetNewQuestion() { // we had a player land on and answer our question, we need a new one







        answers = new string[4]; // reset the answers string array
        
        // ask for question and get info from DB at start
        questionHandler.GetQ(difficulty, classType);

        // get the text of the question
        text = questionHandler.getText();

        int temp = Random.Range(0, 4); // random from zero to 3

        answers[temp] = questionHandler.getCorrect(); // make that the correct question
        correctAnswer = questionHandler.getCorrect(); // save the correct answer so we know what it is

        int t = 0; // we need this since the wrong answer array and the answers arrray are not the same size

        for (int i = 0; i < 4; i++) // go through all four spaces
        {
            if (answers[i] == null) // if the space in the answer array is empty
            { // put a incorrect answer in the answer array
                answers[i] = questionHandler.getWrong(t);
                t++; // incrament t
                }
        }
        // we have the text and the answers

        questionHandler.SetQuestionAsUsed(text);



    }





    // Use this for initialization
    void Start () {
        


        // get tile face based on the tile type





    }
	
	// Update is called once per frame
	void Update () {
        // are we waiting if not return
        if (isWaiting == false)
        {
            return;
        }
        else {// if yes, check to see if our answer is checked
            if (gotAnswer == true) {
                isWaiting = false; // we are not waitng any longer
                //check the answer
                if (givenAnswer == correctAnswer)
                {
                    gameInfo.GetActivePlayer().SetScore(200); // increase score
                    gameInfo.GetActivePlayer().SetHours(-4); //decrease hours
                }
                else { // you were wrong 
                    gameInfo.GetActivePlayer().SetHours(-4); //decrease hours
                }
                //say if its correct or incorrect
                //TODO

                //get a new question

                GetNewQuestion();

                // we are done


            }
        }
        
        // if answer is checked, we have an answer and we are no longer waiting

	}
}
