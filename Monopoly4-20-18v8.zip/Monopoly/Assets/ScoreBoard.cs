﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


// this will deal with the scoreboard and handle updating 


public class ScoreBoard : MonoBehaviour {

    public GameBoard gameinfo; // this is a reference to the game board that we wil be pulling data from
    public Text player1Score; // references to the text objects on the scoreboard
    public Text player2Score;
    public Text player3Score;
    public Text player4Score;
    public Text curTurn;
    public Text player1Name;
    public Text player2Name;
    public Text player3Name;
    public Text player4Name;
    //public int turnsLeft; // this is local copy of turns left the one in Game board is just total turns update this when turn is done

    // Use this for initialization
    void Start () { // set all names and the turns


        
    }
	
	// Update is called once per frame
	void Update () { // every frame we need to update info on the score and tun count

        // names have to be in update and not start because they will grab the default values instead of the real values, WHAT? 
        player1Name.text = gameinfo.players[0].playerName;
        player2Name.text = gameinfo.players[1].playerName;
        player3Name.text = gameinfo.players[2].playerName;
        player4Name.text = gameinfo.players[3].playerName;





        player1Score.text = "" + gameinfo.players[0].score; // lame way to convert string to int, I know, but it works
        player2Score.text = "" + gameinfo.players[1].score;
        player3Score.text = "" + gameinfo.players[2].score;
        player4Score.text = "" + gameinfo.players[3].score;
        curTurn.text = "Current turn = " + gameinfo.numberOfTurns;
    }
}
