﻿using System;
using MySql.Data.MySqlClient;
//using MySql.Data;
using UnityEngine;
using System.Data;



    public class Question : MonoBehaviour
    {





        int i;
        private string questionText;
        private string correctAnswer;
        private string[] wrongAnswer = new string[4];

        public Question GetQ(int diff, string subj)
        {
            //Initialize return Object
            Question Q = new Question();



            //ConnectionString to the SQL Database
            MySqlConnectionStringBuilder connectionString = new MySqlConnectionStringBuilder
            {
                Server = "monopoly.ci9lybjwdv5i.us-east-1.rds.amazonaws.com",
                Port = 3306,
                UserID = "RUPennyBags",
                Password = "FV8c2a7RMrLHM7gK",
                Database = "MonopolyQuestions"
            };
            MySqlConnection connection = new MySqlConnection(connectionString.ToString());




            //Try opening connection to SQL server
            try
            {

                connection.Open();

            Start: //This Label is used to restart the selecting of a question should the questions have to be reset

            //Setup the command to retrieve an unused question with provided difficulty and subject
            MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT id, qText, answers FROM questions " +
                                      "WHERE difficulty = " + diff + " AND subject = '" + subj +
                                      "' AND used = 0 ORDER BY RAND() LIMIT 1;";


                //Execute command
                MySqlDataReader reader = command.ExecuteReader();
                string answers = null;
                int id;
                //...and store values
                while (reader.Read())
                {
                    id = Int32.Parse(reader["id"].ToString());
                    Q.questionText = reader["qText"].ToString();
                    answers = reader["answers"].ToString();
                }

            //If no questions are found
            if (answers == null)
            {
                command.CommandText = "UPDATE questions" +
                                      "WHERE difficulty = " + diff + " AND subject = '" + subj +
                                      "SET used = 0;";
                command.ExecuteNonQuery();
                goto Start;
            }



            //Parse the answers apart by the delimiter |
            else
                {
                    string[] parse = new string[4];
                    parse = answers.Split('|');
                    Q.correctAnswer = parse[0];
                    Q.wrongAnswer[0] = parse[1];
                    Q.wrongAnswer[1] = parse[2];
                    Q.wrongAnswer[2] = parse[3];
                }

                //Close connection when done
                try
                {
                    connection.Close();
                }
                //Throw an exception if we can't close
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }

            }

            //Throw an exception if we can't connect
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                connection.Close();
            }

            return Q;

        }

    public void SetQuestionAsUsed(string questionText)
    { // we had a player land on and answer our question correct, we need to set as used


        //ConnectionString to the SQL Database
        MySqlConnectionStringBuilder connectionString = new MySqlConnectionStringBuilder
        {
            Server = "monopoly.ci9lybjwdv5i.us-east-1.rds.amazonaws.com",
            Port = 3306,
            UserID = "RUPennyBags",
            Password = "FV8c2a7RMrLHM7gK",
            Database = "MonopolyQuestions"
        };
        MySqlConnection connection = new MySqlConnection(connectionString.ToString());


        //Try opening connection to SQL server
        try
        {

            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "UPDATE questions" +
                                  "WHERE qText = '" + questionText +
                                  "' SET used = 1;";
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.ToString());
        }

    }


    //Retrieve the text for the question to ask
    public string getText()
        {
            return this.questionText;
        }

        //Retrieve the correct answer text
        public string getCorrect()
        {
            return this.correctAnswer;
        }

        //Pass in an index and retrieve a wrong answer
        //Index of 1-3
        public string getWrong(int index)
        {
            return this.wrongAnswer[index];
        }
    }