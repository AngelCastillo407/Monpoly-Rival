﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public Tile currentTile;
    //Dice_Roller Roller;
    public int score;
    public int hours;
    public string playerName;
    public bool probation;
    public bool isAnimating; // are we animating yet
    public Sprite piece;
    public bool isAI; // are we a robot overlord?
    public GameBoard gameInfo; // gameboard ref

    public bool hasMoved;

    public bool isChoosingDirection; // are we choosing a direction

    public string direction; // the directional choice

    Vector3 targetPosition;

    Vector3 velocity = Vector3.zero;

    float smoothTime = 0.25f;

    float smoothTimeVertical = 0.1f;

    float smoothDistance = 0.01f;

    float smoothHeight = 0.5f;

    int spacesLeft;




    // Use this for initialization
    void Start ()
    {
        //Roller = GameObject.FindObjectOfType<Dice_Roller>();
        //score = 0;
        //hours = 120;
        //probation = false;

	}




    //needs an int to know how many spaces to move
    public void Move(int spaceToMove) {// if we are just moving
        spacesLeft = spaceToMove;
        Debug.Log("Player " + playerName + " Moving  " + spacesLeft + "\n");
        
        while (spacesLeft != 0) // while we still have spaces to move
        {
            if (currentTile.isDirectional == true) {// if we are on a directional tile

                // do directional stuff ie choose direction

                isChoosingDirection = true;
                GetDirection(); // starts the direction chain

                /* this went in move direction
                if (direction == "left") // we going left
                {
                    currentTile = currentTile.nextTile;
                }
                else if (direction == "right") { // or right
                    currentTile = currentTile.otherNextTile;
                }

                //animate move

                targetPosition = currentTile.transform.position; // set our target 
                isAnimating = true; // we are animating
                */

                //transform.position = currentTile.transform.position; // make the sprite have the same postion as the current tile
                return;


            } else if (currentTile.isStart == true) { // if we are the start tile then we get stuff
                // get stuff 

                score = score + 200; // cash money

                //move on
                currentTile = currentTile.nextTile; // make the current tile the next tile
                targetPosition = currentTile.transform.position; // set our target 
                isAnimating = true; // we are animating
                
                //animate move




                //transform.position = currentTile.transform.position; // make the sprite have the same postion as the current tile
            }
            else { // for normal class tiles



                currentTile = currentTile.nextTile; // make the current tile the next tile
                //animate move
                targetPosition = currentTile.transform.position; // set our target 
                isAnimating = true; // we are animating

                //transform.position = currentTile.transform.position; // make the sprite have the same postion as the current tile

            }

            spacesLeft--; // decrament the number of spaces left, IMPORTANT
        }
        //isAnimating = false; // done animating
        // after we are done moving, we land on a tile
        //Land();
    }




    public void Land() {// we are landing on the current space; we only care if its a class space or a chance space

        

        if (currentTile.isClass)
        {//if this is a class space then do class stuff
            Debug.Log("Landed on  " + currentTile.name + "\n");

            currentTile.Land(); // land on the tile

        }
        else if (currentTile.isChance == true) { // this should be a chance space



            //chance stuff
            gameInfo.getEvent(0); // try to get an event


            Debug.Log("Landed on  " + currentTile.name + "\n");
        } 
    }

    public void GetDirection() { // get the direction the player wants to go
        currentTile.GetDirection();
    }

    //Set the tile to an explict value instead of moving (incrementing or decrementing spaces)
    public void SetPosition()
    {

    }

    public Tile GetPosition()
    {
        return this.currentTile;
    }

    //Increase (or decrease) score by the amount passed in
    //Use a negative number to decrease
    public void SetScore(int score)
    {
        this.score += score;
    }

    //Retrieve the score
    public int GetScore()
    {
        return this.score;
    }

    //Increase (or decrease) hours by the amount passed in
    //Use a negative number to decrease
    public void SetHours(int hours)
    {
        this.hours += hours;
    }

    //Retrieve the hours
    public int GetHours()
    {
        return this.hours;
    }

    //Set the name to the string passed in
    public void SetName(string name)
    {
        this.playerName = name;
    }

    //Retrieve the player name
    public string GetName()
    {
        return this.playerName;
    }

    //Set the player to be on or off probation
    public void SetProbation(bool probation)
    {
        this.probation = probation;
    }

    //Find out if player is on probation
    public bool IsProbation()
    {
        return this.probation;
    }

    //Set the piece to the sprite passed in
    public void SetPiece(Sprite piece)
    {
        this.piece = piece;
    }

    //Retrieve the player piece
    public Sprite GetPiece()
    {
        return this.piece;
    }

    public void SetHasMoved(bool z) {
        hasMoved = z;
    }
    public bool GetHasMoved() {
        return hasMoved;
    }

    public bool Animating()
    {
        return this.isAnimating;
    }

    void moveDirection() { // we have the direction now move it
        if (direction == "left") // we going left
        {
            currentTile = currentTile.nextTile;
        }
        else if (direction == "right")
        { // or right
            currentTile = currentTile.otherNextTile;
        }

        //animate move

        targetPosition = currentTile.transform.position; // set our target 
        isAnimating = true; // we are animating
        direction = null; // reset the direction
        spacesLeft--; //decrament the space we just moved
        Move(spacesLeft); // move the rest of the spaces
    }

    

    // Update is called once per frame
    void Update () {
        //Vector3 bar = transform.position; // get our currentposition
        if (isAnimating == false) // we are not animating

        {

            // Nothing for us to do.

            

        }
        else // we are animating
        {
            if (Vector3.Distance(new Vector3(transform.position.x, transform.position.y,transform.position.z), targetPosition) > smoothDistance) // if we are not at our position
            {
                this.transform.position = Vector3.SmoothDamp(
                        this.transform.position,

                        new Vector3(targetPosition.x, targetPosition.y, targetPosition.z),

                        ref velocity,

                        smoothTime);



            }
            else
            { // if we were animating, but we are at our position, then we are no longer animating

                Land(); // finally land
                isAnimating = false; // stop animating

            }
        }

        if (isChoosingDirection == false) //we are not choosing a direction
        {
            // do nothing
        }
        else { //we are choosing a direction 
            if (direction !=null) { // the direction string is not empty
                isChoosingDirection = false; // we got a direction
                moveDirection();

            }

            
        }

        return; // return quickly
    }
}
